import SwiftUI
import RealityKit //kit de realidad aumentada

struct ContentView: View {
    var body: some View {
        VStack {
            ArViewContainer()
        }
    }
}
struct ArViewContainer:UIViewRepresentable{
    
    func makeUIView(context: Context) -> ARView {
        let arView = ARView(frame: .zero)
        arView.debugOptions = [.showWorldOrigin,.showFeaturePoints]
        
        let anchor = AnchorEntity(plane: .horizontal)
        let modelMesh = MeshResource.generateSphere(radius: 0.08)
        let modelMaterial = SimpleMaterial(color : .blue, isMetallic: true)
        let modelEnty = ModelEntity(mesh: modelMesh, materials:
        [modelMaterial])
        //Tenemos que decirle que los coloque, porque aun no esta en escena.
        anchor.addChild(modelEnty)
        arView.scene.addAnchor(anchor)
        return arView
    }
    func updateUIView(_ uiView: UIViewType, context: Context) {}
    //Los puntos que se ven son los planos que está localizando.
}

